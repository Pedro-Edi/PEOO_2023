import sqlite3
# Função para criar o banco de dados e as tabelas
def get_connection():
    """
    Retorna uma conexão com o banco de dados SQLite.
    """
    return sqlite3.connect("duvidas.db")

def criar_banco_e_tabelas():
    """
    Cria o banco de dados SQLite e as tabelas necessárias (aluno e duvidas).
    """
    conn = get_connection()
    cursor = conn.cursor()

    # Criar a tabela 'aluno'
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS aluno (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome_discord TEXT NOT NULL UNIQUE
    )
    ''')

    # Criar a tabela 'duvidas'
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS duvidas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        aluno_id INTEGER NOT NULL,
        aluno_nome TEXT NOT NULL,
        titulo TEXT NOT NULL,
        mensagem TEXT NOT NULL,
        resposta TEXT,
        visualizada BOOLEAN DEFAULT FALSE,
        timestamp_duvida DATETIME ,
        timestamp_resposta DATETIME,      
        FOREIGN KEY (aluno_id) REFERENCES aluno (id)
    )
    ''')

    # Salvar as alterações e fechar a conexão
    conn.commit()
    conn.close()
    print("Banco de dados e tabelas criados com sucesso!")


        
# Testando a criação do banco de dados e das tabelas
if __name__ == "__main__":
    criar_banco_e_tabelas()