from database.coordenador_banco.deletar_resposta import deletar_resposta
from database.coordenador_banco.obter_duvidas import obter_duvidas
from database.coordenador_banco.registrar_resposta_no_banco import registrar_resposta_no_banco


__all__ = ["deletar_resposta","obter_duvidas","registrar_resposta_no_banco"]