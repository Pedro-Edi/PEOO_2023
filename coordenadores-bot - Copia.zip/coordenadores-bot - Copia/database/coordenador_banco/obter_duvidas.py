from database.database import get_connection
from datetime import datetime

def obter_duvidas(tipo):
    conn = get_connection()
    cursor = conn.cursor()

    # Query base para selecionar dúvidas
    query = '''
        SELECT aluno_nome, titulo, mensagem, resposta, visualizada, timestamp_duvida, timestamp_resposta
        FROM duvidas
    '''


    if tipo:
        if tipo == "duvidas_com_resposta":
            query += " WHERE resposta IS NOT NULL"
        elif tipo == "duvidas_sem_resposta":
            query += " WHERE resposta IS NULL"
        elif tipo == "duvidas_nao_visualizadas":
            query += " WHERE resposta IS NOT NULL AND visualizada = 0"


    cursor.execute(query)
    duvidas = cursor.fetchall()
    conn.close()

    duvidas_por_aluno = {}

    for aluno_nome, titulo, mensagem, resposta, visualizada, timestamp_duvida, timestamp_resposta in duvidas:
        if aluno_nome not in duvidas_por_aluno:
            duvidas_por_aluno[aluno_nome] = {}

        duvidas_por_aluno[aluno_nome][titulo] = {
            "mensagem": mensagem,
            "resposta": resposta,
            "visualizada": visualizada,
            "timestamp_duvida": timestamp_duvida,
            "timestamp_resposta": timestamp_resposta
        }

    if tipo == "duvidas_sem_resposta":
        duvidas_nao_respondidas = dict(sorted(
            duvidas_por_aluno.items(),
            key=lambda item: item[1][list(item[1].keys())[0]]["timestamp_duvida"]
        ))

        for aluno_nome, duvidas_dict in duvidas_nao_respondidas.items():
            duvidas_nao_respondidas[aluno_nome] = dict(sorted(
                duvidas_dict.items(),
                key=lambda item: item[1]["timestamp_duvida"]
            ))

        return duvidas_nao_respondidas

    else:
        duvidas_respondidas = dict(sorted(
            duvidas_por_aluno.items(),
            key=lambda item: max(
                [d["timestamp_resposta"] for d in item[1].values() if d["timestamp_resposta"]],
                default=datetime.min
            ),
            reverse=True
        ))

        for aluno_nome, duvidas_dict in duvidas_respondidas.items():
            duvidas_respondidas[aluno_nome] = dict(sorted(
                duvidas_dict.items(),
                key=lambda item: item[1]["timestamp_resposta"],
                reverse=True
            ))

        return duvidas_respondidas
